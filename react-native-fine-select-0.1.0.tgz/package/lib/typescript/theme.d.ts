import type { FineSelectThemeName } from './types';
export interface FineSelectColors {
    background: string;
    card: string;
    text: string;
    border: string;
    placeholder: string;
    inactive: string;
    overlay: string;
    cancelBackground: string;
    cancelText: string;
}
export declare const lightColors: FineSelectColors;
export declare const darkColors: FineSelectColors;
export declare const getColors: (theme?: FineSelectThemeName) => FineSelectColors;
//# sourceMappingURL=theme.d.ts.map