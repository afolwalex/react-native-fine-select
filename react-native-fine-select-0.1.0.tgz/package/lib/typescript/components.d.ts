import React from 'react';
import type { FineSelectOption } from './types';
export declare const RadioIndicator: ({ selected, color, inactiveColor, }: {
    selected: boolean;
    color: string;
    inactiveColor: string;
}) => React.JSX.Element;
export declare const CheckboxIndicator: ({ selected, color, inactiveColor, }: {
    selected: boolean;
    color: string;
    inactiveColor: string;
}) => React.JSX.Element;
export declare const SearchIcon: ({ color }: {
    color: string;
}) => React.JSX.Element;
export declare const CaretDownIcon: ({ color }: {
    color: string;
}) => React.JSX.Element;
export declare const OptionVisual: ({ item }: {
    item: FineSelectOption;
}) => React.JSX.Element | null;
//# sourceMappingURL=components.d.ts.map