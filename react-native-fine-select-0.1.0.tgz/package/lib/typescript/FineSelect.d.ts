import React from 'react';
import type { FineSelectProps } from './types';
declare const FineSelect: (props: FineSelectProps) => React.JSX.Element;
export default FineSelect;
//# sourceMappingURL=FineSelect.d.ts.map